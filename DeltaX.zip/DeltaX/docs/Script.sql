﻿CREATE TABLE [dbo].[Actors] (
    [Id]   INT           IDENTITY (1, 1) NOT NULL,
    [Name] VARCHAR (200) NOT NULL,
    [Sex]  VARCHAR (10)  NOT NULL,
    [DOB]  DATE          NOT NULL,
    [Bio]  VARCHAR (200) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Producers] (
    [Id]   INT           IDENTITY (1, 1) NOT NULL,
    [Name] VARCHAR (200) NOT NULL,
    [Sex]  VARCHAR (10)  NOT NULL,
    [DOB]  DATE          NOT NULL,
    [Bio]  VARCHAR (200) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Movies] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [Name]            VARCHAR (200) NOT NULL,
    [Year_of_Release] INT           NULL,
    [Plot]            VARCHAR (200) NOT NULL,
    [Poster]          VARBINARY (1) NOT NULL,
    [ProducerId]      INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([ProducerId]) REFERENCES [dbo].[Producers] ([Id])
);

CREATE TABLE [dbo].[MovieActor] (
    [Id]      INT IDENTITY (1, 1) NOT NULL,
    [ActorId] INT NULL,
    [MovieId] INT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([ActorId]) REFERENCES [dbo].[Actors] ([Id]),
    FOREIGN KEY ([MovieId]) REFERENCES [dbo].[Movies] ([Id])
);
