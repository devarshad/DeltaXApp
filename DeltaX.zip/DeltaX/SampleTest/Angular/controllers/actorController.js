﻿angular.module('controllers')
.controller('actorController', ['$scope', 'actorService', function ($scope, actorService) {

    $scope.actors = [];

    $scope.add = function () {
        actorService.post($scope.form)
            .then(function (data) {
                $scope.actors.push(data);
            });
    }

    $scope.search = function (e) {
        actorService.search($scope.key)
           .then(function (data) {
               $scope.actors = data;
           });
    }
}]);