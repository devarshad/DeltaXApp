﻿angular.module('controllers', [])
.controller('base', [function () {

}])