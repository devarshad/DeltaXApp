﻿angular.module('controllers')
.controller('producerController', ['$scope', 'producerService', function ($scope, producerService) {

    $scope.producers = [];

    $scope.add = function () {
        producerService.post($scope.form)
            .then(function (data) {
                $scope.producers.push(data);
            });
    }

    $scope.search = function (e) {
        producerService.search(key)
           .then(function (data) {
               $scope.producers = data;
           });
    }
}]);