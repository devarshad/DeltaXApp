﻿angular.module('controllers')
.controller('movieController', ['$scope', 'movieService', function ($scope, movieService) {

    $scope.movies = [];

    movieService.search()
        .then(function (data) {
            $scope.movies = data;
        });

    $scope.search = function (e) {
        var isSearch = true;
        if (e) {
            if (e.which != 13) {
                isSearch = false;
            }
        }
        if (isSearch) {
            movieService.search($scope.key)
                .then(function (data) {
                    $scope.movies = data;
                });
        }
    }

    $scope.add = function () {
        actorService.post($scope.form)
            .then(function (data) {
                $scope.movies.push(data);
            });
    }

    $scope.get = function (id) {
        actorService.get(id)
            .then(function (data) {
                $scope.form.name = data.name;
                $scope.form.id = data.id;
            });
    }

    $scope.update = function () {
        actorService.put($scope.form)
		.then(function (data) {
		    $scope.form = {};
		    $scope.movies = data;
		});
    }
}]);