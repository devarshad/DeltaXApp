﻿angular.module('services')
.factory('producerService', ['$http', '$q', function ($http, $q) {
    var producer = {};

    producer.search = function (key) {
        var d = $q.defer();
        $http.get('/api/producer/search', { params: { key: search } })
        .then(function (data) {
            d.resolve(data);
        }, function (data) {
            d.resolve(data);
        });
        return d.promise;
    };

    producer.post = function (model) {
        var d = $q.defer();
        $http.post('/api/producer/', model)
        .then(function (data) {
            d.resolve(data);
        }, function (data) {
            d.resolve(data);
        });
        return d.promise;
    };

    return producer;
}]);