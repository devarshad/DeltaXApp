﻿angular.module('services')
.factory('actorService', ['$http', '$q', function ($http, $q) {
    var actor = {};

    actor.search = function (key) {
        var d = $q.defer();
        $http.get('/api/actor/search', { params: { key: search } })
        .then(function (data) {
            d.resolve(data);
        }, function (data) {
            d.resolve(data);
        });
        return d.promise;
    };

    actor.post = function (model) {
        var d = $q.defer();
        $http.post('/api/actor/', model)
        .then(function (data) {
            d.resolve(data);
        }, function (data) {
            d.resolve(data);
        });
        return d.promise;
    };
    return actor;
}]);