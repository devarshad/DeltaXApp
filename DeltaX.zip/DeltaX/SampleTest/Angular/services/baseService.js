﻿angular.module('services', [])
.factory('baseServie', [function () {

}])