﻿angular.module('services')
.factory('movieService', ['$http', '$q', function ($http, $q) {
    var movie = {};

    movie.search = function (key) {
        var d = $q.defer();
        $http.get('/api/movie/search', { params: { key: key } })
        .then(function (data) {
            d.resolve(data);
        }, function (data) {
            d.resolve(data);
        });
        return d.promise;
    };

    movie.get = function (id) {
        var defer = $q.defer();
        $http.get('/api/movie/', { params: { 'id': id } })
			.success(function (data) {
			    defer.resolve(data);
			})
			.error(function (data) {
			    defer.resolve(data);
			    console.log('Error: ' + data);
			});

        return defer.promise;
    }

    movie.post = function (model) {
        var d = $q.defer();
        $http.post('/api/movie/', model)
        .then(function (data) {
            d.resolve(data);
        }, function (data) {
            d.resolve(data);
        });
        return d.promise;
    };

    movie.update = function (form) {
        var defer = $q.defer();
        $http.put('/api/movie/', form)
			.success(function (data) {
			    defer.resolve(data);
			})
			.error(function (data) {
			    defer.resolve(data);
			    console.log('Error: ' + data);
			});

        return defer.promise;
    }

    return movie;
}]);