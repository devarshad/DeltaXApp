angular.module('routes', ['ngRoute'])
.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $routeProvider
		.when('/', { redirectTo: '/movie' })
		.when('/home', { redirectTo: '/movie' })
        .when('/actor/add', {
            templateUrl: '/Angular/views/actor/add.html',
            controller: 'actorController'
        })
        .when('/producer/add', {
            templateUrl: '/Angular/views/producer/add.html',
            controller: 'producerController'
        })
        .when('/movie', {
            templateUrl: '/Angular/views/movie/index.html',
            controller: 'movieController'
        })
        .when('/movie/add', {
            templateUrl: '/Angular/views/movie/add.html',
            controller: 'movieController'
        })
        .when('/movie/edit/:id', {
            templateUrl: '/Angular/views/movie/edit.html',
            controller: 'movieController'
        })
		.when('/error', {
		    templateUrl: '/Angular/views/error/index.html',
		    controller: 'errorController'
		})
		.otherwise({ redirectTo: '/error' })
    $locationProvider.html5Mode({ enabled: true, requireBase: false });
}]);