﻿using SampleTest.Models;
using SampleTest.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SampleTest.Controllers
{
    public class MovieController : ApiController
    {
        // GET: api/Values
        [HttpGet]
        public IQueryable<MovieViewModel> Search(string key)
        {

            using (var _ent = new DeltaXEntities())
            {
                return _ent.Movies.Where(mv => mv.Name.Contains(key))
                    .OrderBy(st => st.Year_of_Release).ThenBy(st => st.Name)
                    .Select(mv => new MovieViewModel
                    {
                        Id = mv.Id,
                        Name = mv.Name,
                        Year_of_Release = mv.Year_of_Release,
                        Plot = mv.Plot,
                        Poster = mv.Poster,
                        ProducerName = mv.Producer.Name,
                        Actors = mv.MovieActors.Select(ac => new ActorViewModel
                        {
                            Name = ac.Actor.Name
                        })
                    });
            }
        }


        // GET api/values/5
        public MovieViewModel Get(int id)
        {
            using (var _ent = new DeltaXEntities())
            {
                return _ent.Movies.Where(mv => mv.Id == id)
                                  .Select(mv => new MovieViewModel
                                  {
                                      Id = mv.Id,
                                      Name = mv.Name,
                                      Year_of_Release = mv.Year_of_Release,
                                      Plot = mv.Plot,
                                      Poster = mv.Poster,
                                      ProducerName = mv.Producer.Name,
                                      Actors = mv.MovieActors.Select(ac => new ActorViewModel
                                      {
                                          Name = ac.Actor.Name
                                      })
                                  }).FirstOrDefault();
            }
        }

        // POST: api/Values
        public bool Post(MovieViewModel model)
        {
            using (var _ent = new DeltaXEntities())
            {
                var _movie = _ent.Movies.Add(new Movie
                {
                    Name = model.Name,
                    Year_of_Release = model.Year_of_Release,
                    Plot = model.Plot,
                    Poster = model.Poster,
                    ProducerId = model.ProducerId
                });

                foreach (var actor in model.Actors)
                {
                    _ent.MovieActors.Add(new MovieActor
                    {
                        MovieId = _movie.Id,
                        ActorId = actor.Id
                    });
                }

                return _ent.SaveChanges() > 0;
            }
        }

        // PUT api/values/5
        public IHttpActionResult Put(MovieViewModel model)
        {
            using (var _ent = new DeltaXEntities())
            {
                var _movie = _ent.Movies.FirstOrDefault(mv => mv.Id == model.Id);

                if (_movie == null)
                {
                    return BadRequest("Movie not found!");
                }

                _movie.Name = model.Name;
                _movie.Year_of_Release = model.Year_of_Release;
                _movie.Plot = model.Plot;
                _movie.Poster = model.Poster;
                _movie.ProducerId = model.ProducerId;

                foreach (var actor in model.Actors)
                {
                    var _actor = _movie.MovieActors.FirstOrDefault(ac => ac.ActorId == actor.Id);
                    _actor.ActorId = actor.Id;
                }

                return Ok(_ent.SaveChanges());
            }
        }
    }
}