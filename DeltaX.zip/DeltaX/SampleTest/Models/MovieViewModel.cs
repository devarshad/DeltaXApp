﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleTest.Models
{
    public class MovieViewModel
    {
        public int Id { get; set; }
        public String Name { get; set; }
        public Nullable<int> Year_of_Release { get; set; }
        public string Plot { get; set; }
        public byte[] Poster { get; set; }
        public int ProducerId { get; set; }
        public String ProducerName { get; set; }
        public IEnumerable<ActorViewModel> Actors { get; set; }
    }
}